﻿namespace IrdLibraryClient;

public static class ApiConfig
{
    public static readonly CancellationTokenSource Cts = new();
}