﻿namespace Ps3DiscDumper.Utils;

public static class Patterns
{
    public const string ProductCode = "product_code";
    public const string ProductCodeLetters = "product_code_letters";
    public const string ProductCodeNumbers = "product_code_numbers";
    public const string Title = "title";
    public const string Region = "region";
}