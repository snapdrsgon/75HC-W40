﻿namespace Ps3DiscDumper.Sfo;

public enum EntryFormat : ushort
{
    Utf8 = 0x0004,
    Utf8Null = 0x0204,
    Int32 = 0x0404,
}